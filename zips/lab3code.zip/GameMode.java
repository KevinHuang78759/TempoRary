/*
 * GameMode.java
 *
 * This is the primary class file for running the game.  You should study this file for
 * ideas on how to structure your own root class. This class follows a 
 * model-view-controller pattern fairly strictly.
 *
 * Author: Walker M. White
 * Based on original Optimization Lab by Don Holden, 2007
 * LibGDX version, 2/2/2015
 */
package edu.cornell.gdiac.optimize;

import com.badlogic.gdx.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.assets.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.g2d.freetype.*;

import edu.cornell.gdiac.assets.AssetDirectory;
import edu.cornell.gdiac.util.*;

import javax.annotation.processing.SupportedSourceVersion;

/**
 * The primary controller class for the game.
 *
 * While GDXRoot is the root class, it delegates all of the work to the player mode
 * classes. This is the player mode class for running the game. In initializes all 
 * of the other classes in the game and hooks them together.  It also provides the
 * basic game loop (update-draw).
 */
public class GameMode implements Screen {
	/** 
 	 * Track the current state of the game for the update loop.
 	 */
	public enum GameState {
		/** Before the game has started */
		INTRO,
		/** While we are playing the game */
		PLAY,
		/** When the ships is dead (but shells still work) */
		OVER
	}
	
	// Loaded assets
	/** The background image for the game */
	private Texture background;
	/** The font for giving messages to the player */
	private BitmapFont displayFont;

	/// CONSTANTS
	/** Factor used to compute where we are in scrolling process */
	private static final float TIME_MODIFIER    = 0.06f;
	/** Offset for the shell counter message on the screen */
	private static final float COUNTER_OFFSET   = 5.0f;
	/** Offset for the game over message on the screen */
	private static final float GAME_OVER_OFFSET = 40.0f;
	
	/** Reference to drawing context to display graphics (VIEW CLASS) */
	private GameCanvas canvas;
	
	/** Reads input from keyboard or game pad (CONTROLLER CLASS) */
	private InputController inputController;
	/** Handle collision and physics (CONTROLLER CLASS) */
	private CollisionController physicsController;
	/** Constructs the game models and handle basic gameplay (CONTROLLER CLASS) */
	private GameplayController gameplayController;
	
	/** Variable to track the game state (SIMPLE FIELDS) */
	private GameState gameState;
	/** Variable to track total time played in milliseconds (SIMPLE FIELDS) */
	private float totalTime = 0;
	/** Whether or not this player mode is still active */
	private boolean active;
	
	/** Listener that will update the player mode when we are done */
	private ScreenListener listener;


	/**
	 * Creates a new game with the given drawing context.
	 *
	 * This constructor initializes the models and controllers for the game.  The
	 * view has already been initialized by the root class.
	 */
	public GameMode(GameCanvas canvas) {
		this.canvas = canvas;
		active = false;
		// Null out all pointers, 0 out all ints, etc.
		gameState = GameState.INTRO;

		// Create the controllers.
		inputController = new InputController();
		gameplayController = new GameplayController();
		// YOU WILL NEED TO MODIFY THIS NEXT LINE

		/*
		 * Deciding a cell size:
		 * Per each object, we must hedge the expected number of cells we check (which will decrease
		 * as we increase the size of the cell) with the expected number of objects in each cell (which
		 * will increase with cell size. The rigorous formula for this yielded no meaningful optimal result,
		 * since the absolute minima expected value occurs for at a negative cell size
		 *
		 * Thus, we choose a cell size that is slightly larger than the largest object (the ship, which has radius 17.5)
		 * to get rid of any possibility we need to check higher numbers of cells.
		 */
		physicsController = new CollisionController(canvas.getWidth(), canvas.getHeight(), 40.0f);

	}
	
	/**
	 * Dispose of all (non-static) resources allocated to this mode.
	 */
	public void dispose() {
		inputController = null;
		gameplayController = null;
		physicsController  = null;
		canvas = null;
	}

	/**
	 * Populates this mode from the given the directory.
	 *
	 * The asset directory is a dictionary that maps string keys to assets.
	 * Assets can include images, sounds, and fonts (and more). This
	 * method delegates to the gameplay controller
	 *
	 * @param directory 	Reference to the asset directory.
	 */
	public void populate(AssetDirectory directory) {
		background  = directory.getEntry("background",Texture.class);
		displayFont = directory.getEntry("times",BitmapFont.class);
		gameplayController.populate(directory);
	}

	/**
	 * Update the game state.
	 *
	 * We prefer to separate update and draw from one another as separate methods, instead
	 * of using the single render() method that LibGDX does.  We will talk about why we
	 * prefer this in lecture.
	 *
	 * @param delta Number of seconds since last animation frame
	 */

	int fp = 1;
	int counter = 0;
	private void update(float delta) {

		int nfp = (int) (1f/delta);

		if(nfp - fp > 2 || fp - nfp > 2){
			System.out.println(fp + " " + nfp);
			fp = nfp;
			System.out.println(counter);
			counter = 0;
		}

		++counter;

		// Process the game input
		inputController.readInput();

		// Test whether to reset the game.
		switch (gameState) {
		case INTRO:
			gameState = GameState.PLAY;
			gameplayController.start(canvas.getWidth() / 2.0f, physicsController.getFloorLedge());
			break;
		case OVER:
			if (inputController.didReset()) {
				gameState = GameState.PLAY;
				gameplayController.reset();
				gameplayController.start(canvas.getWidth() / 2.0f, physicsController.getFloorLedge());
			} else {
				play(delta);
			}
			break;
		case PLAY:
			play(delta);
			break;
		default:
			break;
		}
	}
	int done = 0;
	
	/**
	 * This method processes a single step in the game loop.
	 *
	 * @param delta Number of seconds since last animation frame
	 */
	protected void play(float delta) {
		// if no player is alive, declare game over
		if (!gameplayController.isAlive()) {
			gameState = GameState.OVER;
		}

		// Add a new shell if time.
		if (RandomController.rollInt(0, 25) == 0 || inputController.didFlood()) {
			gameplayController.addShell(canvas.getWidth(), canvas.getHeight());
		}

		// Update objects.
		gameplayController.resolveActions(inputController,delta);

		// Check for collisions
		totalTime += (delta*1000); // Seconds to milliseconds
		float offset =  canvas.getWidth() - (totalTime * TIME_MODIFIER) % canvas.getWidth();
		physicsController.processCollisions(gameplayController.getObjects(),(int)offset);

		// Clean up destroyed objects
		gameplayController.garbageCollect();
	}
	
	/**
	 * Draw the status of this player mode.
	 *
	 * We prefer to separate update and draw from one another as separate methods, instead
	 * of using the single render() method that LibGDX does.  We will talk about why we
	 * prefer this in lecture.
	 */
	private void draw(float delta) {
		float offset = -((totalTime * TIME_MODIFIER) % canvas.getWidth());
		canvas.begin();
		canvas.drawBackground(background,offset,-100);
		// Draw the game objects
		for (GameObject o : gameplayController.getObjects()) {
			o.draw(canvas);
		}

		// Output a simple debugging message stating the number of shells on the screen
		displayFont.setColor(Color.RED);

		String message = "Current shells: "+gameplayController.getShellCount();
		canvas.drawText(message, displayFont, COUNTER_OFFSET, canvas.getHeight()-COUNTER_OFFSET);
		if(gameplayController.isAlive()){
			if(gameplayController.getPlayer().isInvincible()){
				displayFont.setColor(Color.BLUE);
				String message2 = "You are INVINCIBLE!!";
				canvas.drawText(message2, displayFont, COUNTER_OFFSET, canvas.getHeight()-COUNTER_OFFSET*45);
			}
			displayFont.setColor(Color.RED);
			String message2 = "Current Points: "+gameplayController.getPlayer().getPoints();
			canvas.drawText(message2, displayFont, COUNTER_OFFSET, canvas.getHeight()-COUNTER_OFFSET*15);
			displayFont.setColor(Color.RED);
			String message3 = "Current High Score: "+ gameplayController.gethighscore();
			canvas.drawText(message3, displayFont, COUNTER_OFFSET, canvas.getHeight()-COUNTER_OFFSET*30);

		}




		if (gameState == GameState.OVER) {
			canvas.drawTextCentered("Game Over!",displayFont, GAME_OVER_OFFSET);
			canvas.drawTextCentered("Press R to Restart", displayFont, 0);
			if(gameplayController.newhsreached()){
				canvas.drawTextCentered("New High Score: " + gameplayController.gethighscore(), displayFont, 100);
			}
		}

		// Flush information to the graphic buffer.
		canvas.end();
	}
	
	/**
	 * Called when the Screen is resized. 
	 *
	 * This can happen at any point during a non-paused state but will never happen 
	 * before a call to show().
	 *
	 * @param width  The new width in pixels
	 * @param height The new height in pixels
	 */
	public void resize(int width, int height) {
		// IGNORE FOR NOW
	}

	/**
	 * Called when the Screen should render itself.
	 *
	 * We defer to the other methods update() and draw().  However, it is VERY important
	 * that we only quit AFTER a draw.
	 *
	 * @param delta Number of seconds since last animation frame
	 */
	public void render(float delta) {
		if (active) {
			update(delta);
			draw(delta);
			if (inputController.didExit() && listener != null) {
				listener.exitScreen(this, 0);
			}
		}
	}

	/**
	 * Called when the Screen is paused.
	 * 
	 * This is usually when it's not active or visible on screen. An Application is 
	 * also paused before it is destroyed.
	 */
	public void pause() {
		// TODO Auto-generated method stub
	}

	/**
	 * Called when the Screen is resumed from a paused state.
	 *
	 * This is usually when it regains focus.
	 */
	public void resume() {
		// TODO Auto-generated method stub
	}
	
	/**
	 * Called when this screen becomes the current screen for a Game.
	 */
	public void show() {
		// Useless if called in outside animation loop
		active = true;
	}

	/**
	 * Called when this screen is no longer the current screen for a Game.
	 */
	public void hide() {
		// Useless if called in outside animation loop
		active = false;
	}

	/**
	 * Sets the ScreenListener for this mode
	 *
	 * The ScreenListener will respond to requests to quit.
	 */
	public void setScreenListener(ScreenListener listener) {
		this.listener = listener;
	}

}